#!/usr/bin/env bash
# One-shot deploy helper. Usage: ./deploy.sh <stack-name>
# Requires parameters.json (copy from parameters.example.json and fill in).
set -euo pipefail
STACK="${1:-devops-agent-findings}"
[ -f parameters.json ] || { echo "ERROR: parameters.json missing. cp parameters.example.json parameters.json and fill it in."; exit 1; }

# guard against unfilled placeholders
python3 -c "import json,sys; d=json.load(open('parameters.json')); bad=[p['ParameterKey'] for p in d if 'REPLACE' in p['ParameterValue']]; sys.exit('Unfilled: '+', '.join(bad)) if bad else print('params OK ('+str(len(d))+')')"

# build params.yaml (one key per line)
python3 -c "import json; d=json.load(open('parameters.json')); open('params.yaml','w').write('\n'.join(f'{p[\"ParameterKey\"]}: \"{p[\"ParameterValue\"]}\"' for p in d))"

sam build
sam deploy --stack-name "$STACK" \
  --capabilities CAPABILITY_IAM CAPABILITY_AUTO_EXPAND \
  --resolve-s3 --no-confirm-changeset \
  --parameter-overrides file://params.yaml

echo; echo "=== Stack outputs ==="
aws cloudformation describe-stacks --stack-name "$STACK" \
  --query "Stacks[0].Outputs" --output table
