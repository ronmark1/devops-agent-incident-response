# HANDOFF — AWS DevOps Agent → RingCentral Glip → Freshservice pipeline

Paste this into a new chat to continue the build.

## What it is
A single self-contained AWS Lambda (SAM stack `devops-agent-findings`) that turns a
CloudWatch alarm into: create Freshservice ticket → trigger AWS DevOps Agent
investigation (HMAC webhook) → on `Investigation Completed` EventBridge event, read
real root cause and post ONE RingCentral Glip Adaptive Card with Approve/Reject →
on APPROVE, run an SSM runbook (Diagnose mode) and resolve the ticket. Validated
end-to-end in staging (account 163240833505, us-east-1).

## Environment
- Staging AWS account 163240833505, us-east-1, via CloudShell.
- DevOps Agent Space ID: 9ae64870-a95b-471a-b1ba-bc53eb188665
- Stack `devops-agent-findings`. Outputs: AlarmTopicArn
  arn:aws:sns:us-east-1:163240833505:devops-agent-findings-alarms, a public
  Function URL for approve/reject, SSM runbook `devops-agent-findings-mitigation`.
- Project at ~/findings-handler/ (template.yaml, functions/findings_handler/app.py,
  parameters.json → params.yaml → deploy).
- Old stack `devops-agent-integration` was deleted (stop stuck Step Functions
  executions first if it hangs).

## Completed & tested (order 1→3→4 + mitigation display)
1. Ticket-per-alarm dedup (env TicketDedupWindowSeconds default 3600; SSM params
   under /findings-handler/).
3. Summary-parser widening + hide empty "What Happened" + markdown prettify
   (##→bold, -→•).
4. Approve/reject single-use (atomic SSM put_parameter Overwrite=False under
   /findings-handler/decided/{task_id}) + signed expiry (env ApprovalTtlSeconds
   default 14400 = 4h).
- Mitigation display: console deep link
  https://{agent_space_id}.aidevops.global.app.aws/investigation/{task_id}.
- TWO-PHASE MITIGATION (working): Investigation Completed is now SILENT (stashes
  root-cause summary+priority in SSM /findings-handler/inv/{task_id}, triggers
  auto_generate_mitigation via chat create_chat+send_message). Mitigation Completed
  fetches the real plan (get_mitigation_plan: reversed scan + skip-list +
  action-words) and posts ONE consolidated card. Mitigation Failed/Timed Out posts
  the card with root cause only so there is always exactly one message. IAM
  broadened: aidevops:CreateChat/SendMessage/ListBacklogTasks/ListExecutions/
  ListPendingMessages.
- Card cosmetics: _prettify strips 'Description:' labels + 'Cascades to:' lines.

## Hard-won API facts (do NOT re-derive)
- Webhook HMAC: base64(HMAC-SHA256(secret, "{ts}:{body}")); ts ISO-8601 with REAL
  ms via `datetime...microsecond // 1000` (the ".000Z" form → 403).
- Root cause: list_journal_records(recordType="investigation_summary_md") on the
  investigation execution. Works.
- Mitigation is NOT auto-generated for synthetic/no-impact alarms (Agent produces
  none by design). It is NOT in journal records / list_executions /
  list_recommendations / list_assets (assets = agent-space skills/memory, not
  per-investigation plans; the Agent's "use GetAsset" advice was wrong). It CAN be
  triggered/fetched via chat API (create_chat → send_message; response is an
  EventStream in resp["events"]; text at contentBlockDelta.delta.textDelta.text)
  but re-derives async and returns "no mitigation" for test alarms. Decision:
  ship root cause + console deep link; real incidents produce real mitigations.

## Deploy pattern (CloudShell) — avoid --guided
python3 -c "import json; d=json.load(open('parameters.json')); open('params.yaml','w').write('\n'.join(f'{p[\"ParameterKey\"]}: \"{p[\"ParameterValue\"]}\"' for p in d))"
sam build && sam deploy --stack-name devops-agent-findings --capabilities CAPABILITY_IAM CAPABILITY_AUTO_EXPAND --resolve-s3 --no-confirm-changeset --parameter-overrides file://params.yaml

Gotchas: --guided ignores params.yaml & reprompts; `echo >>` glues YAML lines (use
printf '\nKey: "v"\n'); stack/SSM names can't start with "aws"; use FRESH alarm
names per test (Agent links repeats within ~20 min → no card); CloudShell boto3
upgrade conflicts with SAM's pinned boto3[crt]==1.43.7 (restore only if SAM breaks;
deployed Lambda uses runtime boto3, no asset API needed).

## Files
README.md, template.yaml, functions/findings_handler/app.py,
parameters.example.json (13 params), deploy.sh, .gitignore, HANDOFF.md.
Latest validated code = all four improvements above.

## Left to do
- STAGE 2 (NEXT): map a real remediation action from the mitigation text ->
  Option A (human clicks allow-listed action button: Reboot/Restart/Refresh) +
  tag guardrail (act only on resources tagged devops-agent-remediation=allowed,
  via env toggle). Parser reference = the RUN_MITIGATION branch of the user's
  earlier working Lambda. NEEDS a real incident to build against (synthetic
  alarms produce 'no mitigation'). Runbook currently always runs Diagnose.
- Deploy to prod (separate account): own Agent Space + webhooks + Freshservice
  values + fresh ApprovalSigningKey; stack `devops-agent-findings-prod`; point prod
  alarms at its AlarmTopicArn.
- Hardening: rotate secrets shared in original session; consider API Gateway+WAF in
  front of the public Function URL; tighten Resource:'*' IAM to specific ARNs.

Attach the release bundle (or app.py + template.yaml) to the new chat so the
assistant works from the actual latest code.
